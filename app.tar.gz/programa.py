import pandas as pd
import instaloader

L = instaloader.Instaloader()

L.load_session_from_file("itskarla_31")

profile = instaloader.Profile.from_username(L.context, "nomas_mariana")

followings = [followee.username for followee in profile.get_followees()]
followings_df = pd.DataFrame(followings)
followings_df.to_csv('followings.csv', index=False)
