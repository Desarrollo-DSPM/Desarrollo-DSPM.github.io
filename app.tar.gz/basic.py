import flet as ft

def main(page: ft.Page):
    # add/update controls on Page
    pass

ft.app(target=main)