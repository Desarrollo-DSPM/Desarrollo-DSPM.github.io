import flet

def main(page: flet.Page):
    pass

flet.app(target=main)